import ExpenseTrack from './components/ExpenseTrack';
import { useState } from 'react'
import './App.css'

function App() {
  // const [expenses,setExpenses] = useState([]);
  // const [name,setName] = useState("");
  // const [amount,setAmount] = useState("");
  // const [edit,setEdit] = useState(-1);

  // const handleSubmit = (e) => {
  //   e.preventDefault();

    
  // }
  

  return (
    <>
    <h2>📈💰<ExpenseTrack/></h2>

     
    </>
  )
}

export default App
