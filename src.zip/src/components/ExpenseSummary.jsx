import React from 'react'

export default function ExpenseSummary({proexpenses}) {
    const income = proexpenses
    .filter((e) => e.amount > 0)
    .reduce((acc,curr) => acc + curr.amount,0);
    const expenses = proexpenses
    .filter((e) => e.amount < 0)
    .reduce((acc,curr) => acc + curr.amount,0)

    const balance = income + expenses;

    return (
    <div>ExpenseSummary
        <h3>Summary</h3>
        <p>Income: {income}</p>
        <p>Expenses: {Math.abs (expenses)}</p>
        <p>Balance: {balance}</p>
      
     

    </div>
  )
}
