import React from 'react'

export default function ExpenseList({proexpenses,handleDelete}) {
  return (
    <div>ExpenseList
    {proexpenses.map((item) => (
        <div key={item.id}>
            {item.title}&nbsp; - {item.amount}&nbsp;&nbsp;
            <button onClick={() => handleDelete(item.id)}>Delete</button> 
            {/* <button>sample</button> */}
        </div>
    ))}
    </div>
  )
}
