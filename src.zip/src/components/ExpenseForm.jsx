import React, { useState } from "react";



export default function ExpenseForm({ addExpense }) {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !amount) return;
    addExpense(title, amount); // now works fine
    setTitle(""); // clear after submit
    setAmount("");
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>Title</label>&nbsp;
        <input
          type="text"
          placeholder="Enter a Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <br />
        <label>Amount</label>&nbsp;
        <input
          type="number"
          placeholder="Enter an Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <br />
        <br />
        <button>
          <b>SUBMIT</b>
        </button>&nbsp;
      </form>
    </div>
  );
}
