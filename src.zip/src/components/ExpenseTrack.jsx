import React, { useState } from "react";
import ExpenseForm from "./ExpenseForm";
import { v4 as uid } from "uuid";
import ExpenseList from "./ExpenseList";
import ExpenseSummary from "./ExpenseSummary";

const EXPENSES = [
  { id: uid(), title: "Expenses 1", amount: 100 },
  { id: uid(), title: "Expenses 2", amount: -200 },
];

export default function ExpenseTrack() {
  const [expenses, setExpenses] = useState(EXPENSES);

  const addExpense = (title, amount) => {
    setExpenses([
      ...expenses,
      {
        id: uid(),
        title,
        amount: Number(amount),
      },
    ]);
  };
  const handleDelete = (id) => {
    setExpenses(expenses.filter((item) => item.id !== id)); 
  };

  

  return (
    <div>
      <h2>Expense Tracker</h2>
      <ExpenseForm addExpense={addExpense} />

      {/* <ul>
        {expenses.map((item) => (
          <li key={item.id}>
            {item.title} - {item.amount}
          </li>
        ))}
      </ul> */}
      <ExpenseList proexpenses={expenses} handleDelete={handleDelete}/>

     {/* summary */}
     <ExpenseSummary proexpenses={expenses} />

    </div>
  );
}
